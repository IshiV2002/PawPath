KND_04 Notebook 7 input bundle

Upload this matching ZIP beside Notebook 7; it extracts automatically.
Contains training and validation data, preprocessing helper code and the
initial Notebook 6 comparison for the same data. No test data is included.
Notebook 7 refits all preprocessing separately inside each training fold.
Library versions used for verification are in requirements_step7.txt.
The notebook can take several minutes because it compares 24 settings across
three time-ordered folds, then fits one selected setting per model family.
