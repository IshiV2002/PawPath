KND_04 Notebook 6 inputs

This matching bundle contains training and validation inputs and labels only.
It excludes all test records and test labels.
The notebook automatically extracts the ZIP if its input folder is absent.
Upload the ZIP beside Notebook 6 in Colab, then run all cells in order.
Do not edit the files inside the ZIP or mix them with another run.
Requirements list the versions used for verification (Python 3.12).

The helper code is copied from Step 5. Notebook 6 creates a fresh copy of the
preprocessing pipeline for each model and fits it only on training data.
Outcome labels, IDs and audit dates never become prediction inputs.
