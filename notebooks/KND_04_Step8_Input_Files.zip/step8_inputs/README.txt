KND_04 Step 8 input bundle
Contains the exact frozen Notebook 7 model, its cutoff, and 1,672 test rows.
This bundle matches the checked Notebook 7 run, not a different local fit.
Upload this ZIP beside Notebook 8; the notebook extracts it automatically.
Do not combine it with another model or alter the threshold after testing.
Use the model library versions in requirements_step8.txt. If the notebook
requests them, run the printed pip command, restart the session, and Run all.
step8_helpers.py contains file/version/date/overlap checks and saving code.
All model prediction and score calculation steps remain in the notebook.
