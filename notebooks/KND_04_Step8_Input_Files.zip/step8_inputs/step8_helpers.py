"""File checks and saving for Notebook 8. No model training or tuning here."""
from pathlib import Path
import hashlib
import importlib
import importlib.metadata
import json
import shutil
import sys
import warnings


def fingerprint(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_files(folder):
    folder = Path(folder)
    manifest = json.loads((folder / 'input_manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['files_sha256'].items():
        if Path(name).name != name or fingerprint(folder / name) != expected:
            raise ValueError(f'{name} does not match. Upload the complete matching Step 8 ZIP.')
    return manifest


def check_libraries(folder):
    """Stop before loading a saved model with incompatible library versions."""
    check_files(folder)
    policy = json.loads((Path(folder) / 'selection_policy.json').read_text())
    differences = []
    modules = {'scikit-learn': 'sklearn', 'matplotlib': 'matplotlib'}
    for package, expected in policy['versions'].items():
        try:
            installed = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            installed = 'not installed'
        module = sys.modules.get(modules.get(package, package))
        loaded = getattr(module, '__version__', installed)
        if installed != expected or loaded != expected:
            differences.append(f'{package}: need {expected}, installed {installed}, loaded {loaded}')
    if differences:
        print('\n'.join(differences))
        print('Run this in a NEW cell, then restart the session and run this notebook again:')
        print(f'%pip install -r "{Path(folder) / "requirements_step8.txt"}"')
        raise RuntimeError('Use the saved model library versions. See the install command above.')
    print('File and library checks passed.')


def load_saved_model(folder):
    import joblib
    from sklearn.exceptions import InconsistentVersionWarning
    folder = Path(folder)
    check_files(folder)
    policy = json.loads((folder / 'selection_policy.json').read_text())
    plan = json.loads((folder / 'evaluation_plan.json').read_text())
    assert fingerprint(folder / 'selected_model.joblib') == policy['model_sha256'] == plan['model_sha256']
    assert fingerprint(folder / 'shelter_preprocessing.py') == policy['helper_sha256']
    assert policy['alert_threshold'] == plan['alert_threshold']
    assert policy['target'] == 'long_stay_30' and policy['positive_class'] == 1
    sys.path.insert(0, str(folder.resolve()))
    importlib.invalidate_caches()
    sys.modules.pop('shelter_preprocessing', None)
    with warnings.catch_warnings():
        warnings.simplefilter('error', InconsistentVersionWarning)
        model = joblib.load(folder / 'selected_model.joblib')
    assert list(model.named_steps['model'].classes_) == [0, 1]
    assert model.named_steps['preprocess'].named_steps['features'].fit_rows_ == policy['fit_rows'] == 6096
    preprocessing_code = importlib.import_module('shelter_preprocessing')
    assert preprocessing_code.RAW_INPUT_FIELDS == policy['raw_input_fields']
    assert model.named_steps['model'].n_features_in_ == 193
    for key, value in policy['candidate']['params'].items():
        assert model.named_steps['model'].get_params()[key] == value
    return model, policy


def load_test_data(folder, policy):
    import pandas as pd
    folder = Path(folder)
    manifest = check_files(folder)
    X = pd.read_csv(folder / 'test_inputs.csv')
    answers = pd.read_csv(folder / 'test_labels_and_audit.csv', dtype={'id': 'string', 'impound_number': 'string'})
    earlier = pd.read_csv(folder / 'earlier_split_audit.csv', dtype={'id': 'string'})
    assert len(X) == len(answers) == manifest['test_rows'] == 1672
    assert list(X.columns) == policy['raw_input_fields']
    assert 'long_stay_30' not in X and 'id' not in X
    assert answers.source_row_number.is_unique and answers.id.notna().all()
    assert answers['split'].eq('test').all()
    assert set(answers.long_stay_30) == {0, 1}
    assert pd.to_datetime(X.intake_date).equals(pd.to_datetime(answers.intake_date))
    assert set(answers.id).isdisjoint(earlier.id)
    assert set(answers.source_row_number).isdisjoint(earlier.source_row_number)
    dates = pd.to_datetime(answers.intake_date)
    assert dates.min() == pd.Timestamp(manifest['test_start'])
    assert dates.max() == pd.Timestamp(manifest['test_end'])
    assert pd.to_datetime(answers.label_known_date).le(pd.Timestamp(manifest['observation_date'])).all()
    previous = earlier.loc[earlier['split'].eq('validation')]
    assert pd.to_datetime(previous.intake_date).lt(pd.Timestamp('2025-12-01')).all()
    assert pd.to_datetime(earlier.label_known_date).lt(pd.Timestamp(manifest['test_start'])).all()
    print('Row order, dates, answers and animal separation checked.')
    return X, answers


def create_viva_text(policy, answers, metrics, baseline, counts):
    tn, fp, fn, tp = map(int, counts)
    return f'''KND_04 - Notebook 8: final test evaluation

Member 1 - What we tested
"We used the Random Forest model saved in Notebook 7. We kept its alert cutoff
at {policy['alert_threshold']:.2f}. We tested it on {len(answers):,} later admissions, from 1 January to
14 August 2026. We did not train the model or change the cutoff here."

Member 2 - Predictions and mistakes
"Our target is whether an animal stays more than 30 days. One means a long
stay, and zero means 30 days or less. We caught {tp} long stays and missed
{fn}. We also raised {fp} false alerts. There were {tn} correctly predicted
short stays. A false alert means we flagged a long stay, but it was short."

Member 3 - What the scores mean
"Recall was {metrics['Recall']:.1%}. That is the share of actual long stays we caught.
Precision was {metrics['Precision']:.1%}. That is the share of our alerts that were right.
We flagged {metrics['Alert share']:.1%} of all arrivals. Our average precision was
{metrics['Average precision']:.4f}, compared with {baseline['Average precision']:.4f} for the constant-score baseline.
Accuracy alone is not enough because predicting short stays for everyone
can look accurate while missing every long stay."

Member 4 - What we can conclude
"These are final test results for the fixed model. We must report the false
alerts as well as the long stays we caught. The model's Brier error was
{metrics['Brier error']:.4f}, compared with {baseline['Brier error']:.4f} for the baseline; lower is better.
We have not shown that model scores are reliable probabilities. The data is
from one US county, so we cannot claim the same performance in Sri Lanka.
We saved the results. We will not use these test answers to adjust the model
and still call this an independent test."

Only claim the work you personally did. Running, reviewing and explaining
a notebook is different from writing its code.
'''


def save_results(folder, results_dir, model, policy, model_state_before,
                 predictions, summary, comparison, counts, viva_text):
    import joblib
    import numpy as np
    from datetime import datetime, timezone
    folder, results_dir = Path(folder), Path(results_dir)
    manifest = check_files(folder)
    assert joblib.hash(model) == model_state_before, 'The loaded model changed during evaluation.'
    assert fingerprint(folder / 'selected_model.joblib') == policy['model_sha256']
    assert predictions.shape[0] == int(sum(counts)) == manifest['test_rows']
    assert np.isfinite(predictions.long_stay_score).all()
    assert predictions.long_stay_score.between(0, 1).all()
    assert np.array_equal(predictions.predicted_long_stay, (predictions.long_stay_score >= policy['alert_threshold']).astype(int))
    predictions.to_csv(results_dir / 'test_predictions.csv', index=False)
    predictions.loc[~predictions.correct].to_csv(results_dir / 'test_mistakes.csv', index=False)
    summary.to_csv(results_dir / 'test_metrics.csv', index_label='Metric')
    comparison.to_csv(results_dir / 'validation_vs_test.csv', index_label='Metric')
    tn, fp, fn, tp = map(int, counts)
    import pandas as pd
    pd.DataFrame([[tn, fp], [fn, tp]], index=['Actual short', 'Actual long'],
                 columns=['Predicted short', 'Predicted long']).to_csv(results_dir / 'confusion_matrix.csv')
    (results_dir / 'viva_summary.txt').write_text(viva_text, encoding='utf-8')
    notes = {'test_evaluated': True, 'model_retrained': False, 'threshold_changed': False,
        'selected_candidate': policy['candidate']['candidate_id'], 'threshold': policy['alert_threshold'],
        'test_rows': len(predictions), 'test_start': manifest['test_start'], 'test_end': manifest['test_end'],
        'model_sha256': policy['model_sha256'], 'input_hashes': manifest['files_sha256'],
        'created_utc': datetime.now(timezone.utc).isoformat(), 'metrics': summary.to_dict(),
        'counts': {'true_short': tn, 'false_alerts': fp, 'missed_long_stays': fn, 'caught_long_stays': tp},
        'limitations': ['One county and one later time period; not deployment evidence.',
            'Multiple visits of one animal can remain within this split; no independence-based confidence intervals claimed.',
            'Labels for blank outcomes assume ongoing stays; historical attribute timing cannot be verified.',
            'Threshold selected for validation F2, not shelter-agreed workload or costs.',
            'No probability calibration fitted.',
            'Test is now evaluated: using its answers to make changes would require new independent evaluation.']}
    (results_dir / 'final_test_notes.json').write_text(json.dumps(notes, indent=2), encoding='utf-8')
    for name in ['selection_policy.json', 'evaluation_plan.json', 'requirements_step8.txt']:
        shutil.copyfile(folder / name, results_dir / name)
    (results_dir / 'README.txt').write_text('''Notebook 8 evaluates the saved Notebook 7 model and cutoff.
No model training, threshold search, calibration fitting or feature selection
is performed here. final_test_notes.json records that the test is now used.
selection_policy.json is a historical copy of the pre-test choice; its
test_evaluated=false flag describes when that choice was originally saved.
Re-running unchanged predictions is a reproducibility check, not a new test.
Keep the Step 8 input ZIP to retain the exact saved model and source files.
test_predictions.csv contains all answers, scores and decisions.
test_mistakes.csv contains every wrong decision, without cherry-picking.
The notebook explains each main step; step8_helpers.py contains the longer
file, version, date, overlap and saving checks. viva_summary.txt contains a
simple four-member speaking guide. Only claim contributions actually made.
''', encoding='utf-8')
    archive = shutil.make_archive(str(results_dir.parent / 'KND_04_Step8_Results'), 'zip',
                                  root_dir=results_dir.parent, base_dir=results_dir.name)
    print('Checks passed: original files and model are unchanged.')
    print('Results folder:', results_dir)
    print('Download:', archive)
    return archive
